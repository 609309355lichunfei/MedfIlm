//
//  Tool.m
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/29.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import "Tool.h"
#import "KSDicom2DView.h"
#import "KSDicomDecoder.h"

#define pi 3.14159265358979323846
#define RadiansToAngle(x) (180.0 * x / pi)
#define AngleToRadian(x) (pi * x / 180.0)


@implementation Tool


+ (Tool *)shareInstance {

    static Tool *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        instance = [[Tool alloc]init];
    });

    return instance;
}

-(CGFloat)angleForStartPoint:(CGPoint)startPoint firstEndPoint:(CGPoint)endPoint secEndPoint:(CGPoint)secEndPoint{
    
    
    CGFloat a = endPoint.x - startPoint.x;
    CGFloat b = endPoint.y - startPoint.y;
    CGFloat c = secEndPoint.x - startPoint.x;
    CGFloat d = secEndPoint.y - startPoint.y;
    
    CGFloat rads = acos(((a*c) + (b*d)) / ((sqrt(a*a + b*b)) * (sqrt(c*c + d*d))));
    
    if (startPoint.y>endPoint.y) {
        rads = -rads;
    }
    return RadiansToAngle(rads);
}

- (void) decodeAndDisplay:(NSString *)path dicomDecoder:(KSDicomDecoder *)dicomDecoder dicom2DView:(KSDicom2DView *)dicom2DView
{
//    dicomDecoder = [[KSDicomDecoder alloc] init];
//    [dicomDecoder setDicomFilename:path];
    
    [self displayWith:0 windowCenter:0 dicomDecoder:dicomDecoder dicom2DView:dicom2DView];
}

- (void) displayWith:(NSInteger)windowWidth windowCenter:(NSInteger)windowCenter dicomDecoder:(KSDicomDecoder *)dicomDecoder dicom2DView:(KSDicom2DView *)dicom2DView
{
    if (!dicomDecoder.dicomFound || !dicomDecoder.dicomFileReadSuccess)
    {
        
        dicomDecoder = nil;
        return;
    }
    
    NSInteger winWidth        = windowWidth;
    NSInteger winCenter       = windowCenter;
    NSInteger imageWidth      = dicomDecoder.width;
    NSInteger imageHeight     = dicomDecoder.height;
    NSInteger bitDepth        = dicomDecoder.bitDepth;
    NSInteger samplesPerPixel = dicomDecoder.samplesPerPixel;
    BOOL signedImage          = dicomDecoder.signedImage;
    
    BOOL needsDisplay = NO;
    
    if (samplesPerPixel == 1 && bitDepth == 8)
    {
        Byte * pixels8 = [dicomDecoder getPixels8];
        
        if (winWidth == 0 && winCenter == 0)
        {
            Byte max = 0, min = 255;
            NSInteger num = imageWidth * imageHeight;
            for (NSInteger i = 0; i < num; i++)
            {
                if (pixels8[i] > max) {
                    max = pixels8[i];
                }
                
                if (pixels8[i] < min) {
                    min = pixels8[i];
                }
            }
            
            winWidth = (NSInteger)((max + min)/2.0 + 0.5);
            winCenter = (NSInteger)((max - min)/2.0 + 0.5);
        }
        
        [dicom2DView setPixels8:pixels8
                               width:imageWidth
                              height:imageHeight
                         windowWidth:winWidth
                        windowCenter:winCenter
                     samplesPerPixel:samplesPerPixel
                         resetScroll:YES];
        
        needsDisplay = YES;
    }
    
    if (samplesPerPixel == 1 && bitDepth == 16)
    {
        ushort * pixels16 = [dicomDecoder getPixels16];
        
        if (winWidth == 0 || winCenter == 0)
        {
            ushort max = 0, min = 65535;
            NSInteger num = imageWidth * imageHeight;
            for (NSInteger i = 0; i < num; i++)
            {
                if (pixels16[i] > max) {
                    max = pixels16[i];
                }
                
                if (pixels16[i] < min) {
                    min = pixels16[i];
                }
            }
            
            winWidth = (NSInteger)((max + min)/2.0 + 0.5);
            winCenter = (NSInteger)((max - min)/2.0 + 0.5);
        }
        
        dicom2DView.signed16Image = signedImage;
        
        [dicom2DView setPixels16:pixels16
                                width:imageWidth
                               height:imageHeight
                          windowWidth:winWidth
                         windowCenter:winCenter
                      samplesPerPixel:samplesPerPixel
                          resetScroll:YES];
        
        needsDisplay = YES;
    }
    
    if (samplesPerPixel == 3 && bitDepth == 8)
    {
        Byte * pixels24 = [dicomDecoder getPixels24];
        
        if (winWidth == 0 || winCenter == 0)
        {
            Byte max = 0, min = 255;
            NSInteger num = imageWidth * imageHeight * 3;
            for (NSInteger i = 0; i < num; i++)
            {
                if (pixels24[i] > max) {
                    max = pixels24[i];
                }
                
                if (pixels24[i] < min) {
                    min = pixels24[i];
                }
            }
            
            winWidth = (max + min)/2 + 0.5;
            winCenter = (max - min)/2 + 0.5;
        }
        
        [dicom2DView setPixels8:pixels24
                               width:imageWidth
                              height:imageHeight
                         windowWidth:winWidth
                        windowCenter:winCenter
                     samplesPerPixel:samplesPerPixel
                         resetScroll:YES];
        
        needsDisplay = YES;
    }
    
    if (needsDisplay)
    {
        //        CGFloat x = (self.view.frame.size.width - imageWidth) /2;
        //        CGFloat y = (self.view.frame.size.height - imageHeight) /2;
        //dicom2DView.frame = CGRectMake(40, 200, SCREEN_WIDTH-40*2, SCREEN_WIDTH-40*2);
        dicom2DView.center = CGPointMake(MedFilm_WIDTH/2, MedFilm_HEIGHT/2);
        dicom2DView.bounds = CGRectMake(0, 0, MedFilm_WIDTH-40*2, MedFilm_WIDTH-40*2);
        [dicom2DView setNeedsDisplay];
        
        if (self.delegate && [self.delegate respondsToSelector:@selector(updateWinWidth:winCenter:)]) {
            [self.delegate updateWinWidth:[NSString stringWithFormat:@"窗宽:%ld",dicom2DView.winWidth] winCenter:[NSString stringWithFormat:@"窗位:%ld",dicom2DView.winCenter]];
        }
    }
}



@end
