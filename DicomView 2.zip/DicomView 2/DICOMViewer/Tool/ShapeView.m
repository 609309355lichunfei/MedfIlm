//
//  ShapeView.m
//  DICOMViewer
//
//  Created by ZJQ on 2017/4/11.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import "ShapeView.h"

@implementation ShapeView

+ (Class)layerClass
{
    return [CAShapeLayer class];
}

- (CAShapeLayer *)shapeLayer
{
    return (CAShapeLayer *)self.layer;
}

@end
