//
//  NSString+Ext.m
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/30.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import "NSString+Ext.h"

@implementation NSString (Ext)


- (BOOL)isNull {

    if ([self isEqualToString:@""] ||
        self == nil ||
        [self isEqualToString:@"null"] ||
        [self isEqualToString:@"<null>"]) {
        
        return YES;
    }
    
    return NO;
}

- (CGFloat)getStringHeightWithWidth:(CGFloat)width font:(CGFloat)font {
    
    CGRect rect = [self boundingRectWithSize:CGSizeMake(width, MAXFLOAT) options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:font]} context:nil];
    
    return ceil(rect.size.height);
}
- (CGFloat)getStringWidthWithHieght:(CGFloat)height font:(CGFloat)font {
    
    CGRect rect = [self boundingRectWithSize:CGSizeMake(MAXFLOAT, height) options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:font]} context:nil];
    
    return ceil(rect.size.width);
}





@end
