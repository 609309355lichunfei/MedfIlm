//
//  GCLoadingLayer.h
//  GCLoadingAnimationOne
//
//  Created by 宫城 on 16/7/25.
//  Copyright © 2016年 宫城. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface GCLoadingLayer : CALayer

- (void)startAnimation;

@end
