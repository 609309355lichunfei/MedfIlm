//
//  MainCell.m
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/30.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import "MainCell.h"

#import "NSString+Ext.h"
@interface MainCell ()



@end

@implementation MainCell


/**
 重写这个方法是为了重新绘制单元格的分割线

 @param rect <#rect description#>
 */
- (void)drawRect:(CGRect)rect {

    [super drawRect:rect];
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [UIColor clearColor].CGColor);
    CGContextFillRect(context, rect);
    
    CGContextSetStrokeColorWithColor(context, [UIColor colorWithRed:225.0/255.0 green:225.0/255.0 blue:225.0/255.0 alpha:1.0].CGColor);
    CGContextStrokeRect(context, CGRectMake(0, 0, MedFilm_WIDTH, 0.5));
    
    
    CGContextSetStrokeColorWithColor(context, [UIColor colorWithRed:225.0/255.0 green:225.0/255.0 blue:225.0/255.0 alpha:1.0].CGColor);
    CGContextStrokeRect(context, CGRectMake(0, rect.size.height-0.5, MedFilm_WIDTH, 0.5));
    
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {

    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        [self.contentView addSubview:self.nameLabel];
        [self.nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
            make.left.offset(10);
            make.top.offset(10);
            make.width.offset(1000);
        }];
        
        
        [self.contentView addSubview:self.numberLabel];
        [self.numberLabel mas_makeConstraints:^(MASConstraintMaker *make) {
           
            make.height.left.equalTo(self.nameLabel);
            make.top.equalTo(self.nameLabel.mas_bottom).offset(5);
        }];
        
        
        [self.contentView addSubview:self.examineTimeLabel];
        [self.examineTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(self.nameLabel);
            make.bottom.offset(-10);
            make.height.offset(8);
        }];
        
        
        [self.contentView addSubview:self.typeLabel];
        [self.typeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
           
            make.top.height.equalTo(self.nameLabel);
            make.left.offset(MedFilm_WIDTH - 200);
        }];
        
        
        [self.contentView addSubview:self.ageLabel];
        [self.ageLabel mas_makeConstraints:^(MASConstraintMaker *make) {
           
            make.center.equalTo(self);
            make.height.offset(10);
        }];
        
        
        [self.contentView addSubview:self.sexLabel];
        [self.sexLabel mas_makeConstraints:^(MASConstraintMaker *make) {
           
            make.left.height.equalTo(self.ageLabel);
            make.top.equalTo(self.examineTimeLabel);
        }];
        
        
        [self.contentView addSubview:self.partLabel];
        [self.partLabel mas_makeConstraints:^(MASConstraintMaker *make) {
           
            make.top.height.equalTo(self.sexLabel);
        }];
    }
    return self;
}

#pragma mark - setter
- (void)setModel:(PatientModel *)model {

    _model = model;
    
    self.nameLabel.text = [NSString  stringWithFormat:@"name :%@",model.name];     
//    [self.nameLabel mas_updateConstraints:^(MASConstraintMaker *make) {
//        make.width.offset([model.name getStringWidthWithHieght:10 font:12]);
//    }];
    
    
    self.numberLabel.text =   [NSString stringWithFormat:@"序号:%@",model.number];
//    [self.numberLabel mas_updateConstraints:^(MASConstraintMaker *make) {
//        make.width.offset([model.number getStringWidthWithHieght:10 font:12]);
//    }];
    
    
    NSString *number = [NSString stringWithFormat:@"检查时间: %@",model.examineTime];
    self.examineTimeLabel.text = number;
    [self.examineTimeLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.offset([number getStringWidthWithHieght:8 font:10]);
    }];
    
    
    self.typeLabel.text = model.type;
    [self.typeLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.offset([model.type getStringWidthWithHieght:10 font:12]+20);
    }];
    
    
    self.ageLabel.text = model.age;
    [self.ageLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.offset([model.age getStringWidthWithHieght:10 font:12]);
    }];
    
    
    self.sexLabel.text = model.sex;
    [self.sexLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.offset([model.sex getStringWidthWithHieght:10 font:12]);
    }];
    
    
    self.partLabel.text = model.part;
    [self.partLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.sexLabel.mas_right).offset(40);
        make.width.offset([model.part getStringWidthWithHieght:10 font:12]);
    }];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

#pragma mark - lazy

- (UILabel *)nameLabel {
    
    if (!_nameLabel) {
        _nameLabel = [UILabel new];
        _nameLabel.font = [UIFont systemFontOfSize:12];
        _nameLabel.textColor = [UIColor blackColor];
    }
    return _nameLabel;
}
- (UILabel *)typeLabel {
    
    if (!_typeLabel) {
        _typeLabel = [UILabel new];
        _typeLabel.font = [UIFont boldSystemFontOfSize:12];
        _typeLabel.textColor = [UIColor blackColor];
    }
    return _typeLabel;
}
- (UILabel *)numberLabel {
    
    if (!_numberLabel) {
        _numberLabel = [UILabel new];
        _numberLabel.font = [UIFont systemFontOfSize:12];
        _numberLabel.textColor = [UIColor blackColor];
    }
    return _numberLabel;
}
- (UILabel *)ageLabel {
    
    if (!_ageLabel) {
        _ageLabel = [UILabel new];
        _ageLabel.font = [UIFont systemFontOfSize:12];
        _ageLabel.textColor = [UIColor blackColor];
    }
    return _ageLabel;
}
- (UILabel *)examineTimeLabel {
    
    if (!_examineTimeLabel) {
        _examineTimeLabel = [UILabel new];
        _examineTimeLabel.font = [UIFont systemFontOfSize:10];
        _examineTimeLabel.textColor = [UIColor blackColor];
    }
    return _examineTimeLabel;
}
- (UILabel *)sexLabel {
    
    if (!_sexLabel) {
        _sexLabel = [UILabel new];
        _sexLabel.font = [UIFont systemFontOfSize:12];
        _sexLabel.textColor = [UIColor blackColor];
    }
    return _sexLabel;
}
- (UILabel *)partLabel {
    
    if (!_partLabel) {
        _partLabel = [UILabel new];
        _partLabel.font = [UIFont systemFontOfSize:12];
        _partLabel.textColor = [UIColor blackColor];
    }
    return _partLabel;
}


@end
