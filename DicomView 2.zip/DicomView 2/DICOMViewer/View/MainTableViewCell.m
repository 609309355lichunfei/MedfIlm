//
//  MainTableViewCell.m
//  DICOMViewer
//
//  Created by 李春菲 on 17/6/20.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import "MainTableViewCell.h"

@implementation MainTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
