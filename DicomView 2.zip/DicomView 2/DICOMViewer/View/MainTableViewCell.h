//
//  MainTableViewCell.h
//  DICOMViewer
//
//  Created by 李春菲 on 17/6/20.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTableViewCell : UITableViewCell

@end
