//
//  MainCell.h
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/30.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PatientModel.h"

@interface MainCell : UITableViewCell

@property (nonatomic, strong) UILabel         *         nameLabel;
@property (nonatomic, strong) UILabel         *         typeLabel;
@property (nonatomic, strong) UILabel         *         sexLabel;
@property (nonatomic, strong) UILabel         *         ageLabel;
@property (nonatomic, strong) UILabel         *         examineTimeLabel;
@property (nonatomic, strong) UILabel         *         partLabel;
@property (nonatomic, strong) UILabel         *         numberLabel;
@property (nonatomic, strong) PatientModel  *   model;



@end
