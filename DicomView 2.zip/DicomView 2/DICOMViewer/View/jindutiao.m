//
//  jindutiao.m
//  DICOMViewer
//
//  Created by 李春菲 on 17/5/22.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import "jindutiao.h"

@implementation jindutiao

-(instancetype)initWithFrame:(CGRect)frame {
    
  
    
   self = [super initWithFrame:frame];
    if (self) {
        
       self.backgroundColor = [UIColor blackColor];
        
    }
    
    return self;
}

@end
