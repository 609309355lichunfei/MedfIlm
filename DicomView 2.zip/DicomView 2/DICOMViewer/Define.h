//
//  Define.h
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/30.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#ifndef Define_h
#define Define_h


#import "Masonry.h"
#import <AFNetworking.h>
#import "PPNetworkHelper.h"
#import "UIResponder+Adapt.h"
#import "MBProgressHUD+HH.h"
#import "MBProgressHUD.h"
#import "NSString+SubstringToInde.h"
#endif /* Define_h */



#ifdef DEBUG
#define PPLog(...) printf("[%s] %s [第%d行]: %s\n", __TIME__ ,__PRETTY_FUNCTION__ ,__LINE__, [[NSString stringWithFormat:__VA_ARGS__] UTF8String])
#else
#define PPLog(...)
#endif
