//
//  NSString+SubstringToInde.m
//  DICOMViewer
//
//  Created by 李春菲 on 17/6/20.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import "NSString+SubstringToInde.h"

@implementation NSString (SubstringToInde)
+ (NSString *)strGetToHttp:(NSString *)getStr{
    
    NSString * subString = [getStr substringFromIndex:3];
    NSString * string1 = @"http";
    getStr = [NSString stringWithFormat:@"%@%@", string1, subString];
    return getStr;
}
@end
