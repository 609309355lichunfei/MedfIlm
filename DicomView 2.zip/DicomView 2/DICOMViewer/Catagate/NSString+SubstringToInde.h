//
//  NSString+SubstringToInde.h
//  DICOMViewer
//
//  Created by 李春菲 on 17/6/20.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (SubstringToInde)
+ (NSString *)strGetToHttp:(NSString *)getStr;
@end
