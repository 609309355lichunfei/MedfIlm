# Dicom
iOS 关于dicom文件的解析和一些常规操作

不停的google和baidu，但是网上的资料都是大部分都是c++的，对我这样一个iOS的来说挑战性很大。柳暗花明又一村。找了好久，找到了一个[大神的杰作](http://blog.csdn.net/kesalin/article/details/6986274)。这套源代码是2011年写的，所以拿到后改了改，然后在网上遇到了一个同样是在做dicom移动端的哥们儿，俩人不停的探讨，才有了现在一点点的小成果。

先上一个效果图：

![这是文件列表](http://upload-images.jianshu.io/upload_images/2074437-e693b3f9651ee192.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

再来一张：

![这是解析粗来的](http://upload-images.jianshu.io/upload_images/2074437-f0733ed269364e20.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

再来个标注效果的：

![这就是标注效果的](http://upload-images.jianshu.io/upload_images/2074437-7511b735e05a438a.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


由于现在很多功能还没有实现，所以还需要不断完善！后面会不定期更新的！

[原文地址](https://zjqian.github.io/2017/04/01/dicomProject/)

最后附上：[源码地址](https://github.com/ZJQian/Dicom)
